export const BOT_NAME = "Free Stuff Bot";
export type Deal = {
  id: string;
  title: string;
  url: string;
  price: number;
  originalPrice: number;
  discount: number;
  expiry: Date;
  source: "EPIC" | "STEAM" | "REDDIT";
  imageUrl?: string;
};
