# Free Stuff / Deals Alert Bot & Dashboard

A self-hosted Discord bot and web dashboard that discovers free games and deals.

## Hosting Architecture
This project uses a **Split Hosting** architecture to maximize free tiers:
1. **Database**: Supabase (PostgreSQL) - Shared state.
2. **Dashboard**: Vercel - Next.js App.
3. **Bot**: Spacifey.eu / VPS - Node.js Process.

## Setup Instructions

### 1. Database (Supabase)
1. Create a new Supabase project.
2. Get your `DATABASE_URL` (Transaction Pooler, port 6543) and `DIRECT_URL` (Session, port 5432).
3. Paste them into `.env`.
4. Run migrations:
   ```bash
   npx prisma generate
   npx prisma db push
   ```

### 2. Dashboard (Vercel)
1. Push this repo to GitHub.
2. Import project into Vercel.
3. Set **Root Directory** to `apps/web`.
4. Add Environment Variables: `DATABASE_URL`, `DIRECT_URL`, `NEXTAUTH_SECRET`, `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`.
5. Deploy.

### 3. Bot (Spacifey / Pterodactyl)
The host runs `node bot.js`. You need to bundle the bot first.

1. **Local Prep**:
   ```bash
   npm install esbuild --save-dev
   node scripts/build-spacifey.js
   ```
   This creates a `deploy-bot` folder.

2. **Upload**:
   Upload the contents of `deploy-bot` to your file manager on Spacifey.
   - `bot.js`
   - `package.json`
   - `prisma/schema.prisma`

3. **Configure Startup**:
   - Ensure Startup Command is: `node bot.js`
   - Set Environment Variables in the panel: `DISCORD_TOKEN`, `DATABASE_URL`, `DIRECT_URL`.

4. **Start**:
   The panel will run `npm install` automatically (based on the package.json we generated), then `node bot.js`.
