const { build } = require('esbuild');
const path = require('path');
const fs = require('fs');

async function bundle() {
    const outDir = path.resolve(__dirname, '../deploy-bot');
    if (!fs.existsSync(outDir)) fs.mkdirSync(outDir);

    console.log('Bundling bot for Docker/Node...');

    // 1. Bundle Bot Code
    await build({
        entryPoints: [path.resolve(__dirname, '../apps/bot/src/index.ts')],
        bundle: true,
        platform: 'node',
        target: 'node18',
        outfile: path.join(outDir, 'bot.js'),
        external: ['discord.js', '@prisma/client', 'dotenv', 'node-cron', 'axios'], // Keep these external to reduce file size issues if native modules
        minify: false,
    });

    // 2. Create Package.json for production
    const pkg = {
        name: "free-stuff-bot-deploy",
        version: "1.0.0",
        main: "bot.js",
        scripts: {
            "start": "node bot.js"
        },
        dependencies: {
            "discord.js": "^14.14.0",
            "dotenv": "^16.3.1",
            "node-cron": "^3.0.3",
            "axios": "^1.6.2",
            "@prisma/client": "^5.10.0"
        }
    };

    fs.writeFileSync(path.join(outDir, 'package.json'), JSON.stringify(pkg, null, 2));

    // 3. Copy Prisma Schema for generation on host
    const prismaDir = path.join(outDir, 'prisma');
    if (!fs.existsSync(prismaDir)) fs.mkdirSync(prismaDir);
    fs.copyFileSync(path.resolve(__dirname, '../packages/db/prisma/schema.prisma'), path.join(prismaDir, 'schema.prisma'));

    console.log('✅ Bundle complete in /deploy-bot');
    console.log('👉 Upload contents of /deploy-bot to Spacifey');
    console.log('👉 Ensure to set DATABASE_URL and DIRECT_URL env vars on host');
}

bundle().catch(err => {
    console.error(err);
    process.exit(1);
});
