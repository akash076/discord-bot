const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Configuration
const DIST_DIR = path.resolve(__dirname, 'deploy-bot');
const BOT_DIR = path.resolve(__dirname, 'apps/bot');
const SHARED_DIR = path.resolve(__dirname, 'packages/shared');
const DB_DIR = path.resolve(__dirname, 'packages/db');

console.log('🚧 Starting Bot Bundle Process for Spacifey...');

// 1. Clean & Create Dist Dir
if (fs.existsSync(DIST_DIR)) {
    fs.rmSync(DIST_DIR, { recursive: true, force: true });
}
fs.mkdirSync(DIST_DIR);

// 2. Build Packages (Assuming tsc is available globally or via npx)
console.log('📦 Building packages/shared...');
execSync('tsc', { cwd: SHARED_DIR, stdio: 'inherit' });

console.log('📦 Building apps/bot...');
execSync('tsc', { cwd: BOT_DIR, stdio: 'inherit' });

// 3. Copy Compile Output
console.log('📂 Copying files...');

// Copy Shared
const distShared = path.join(DIST_DIR, 'node_modules', '@repo', 'shared');
fs.mkdirSync(distShared, { recursive: true });
// Copy generic JS/D.TS files from shared (assuming tsc output is in root or dist depending on config)
// In this repo setup, shared has main: ./index.ts, so we likely need to bundle or just copy ts if using ts-node on host?
// User said "node bot.js", implies compiled JS.
// Our simple setup might be easier to just bundle everything with ncc or esbuild if allowed.
// But we'll try a manual copy approach for "node_modules" simulation.

// Actually, simpler approach for "node bot.js": use ncc (Vercel's compiler) to make ONE file.
// If ncc is not available, we have to copy node_modules.
// Let's assume we can use a small bundler script or just copy dist.

// Copy Bot Dist
// fs.cpSync(path.join(BOT_DIR, 'dist'), DIST_DIR, { recursive: true });

// 4. Create Package.json
const botPackage = require(path.join(BOT_DIR, 'package.json'));
const prodDeps = botPackage.dependencies;

// Remove workspace refs and replace with real versions if possible, or just keep them
// For Spacifey, we can't use "workspace:*". We need to embed the code.
// Ideally usage of `esbuild` to bundle is best.

console.log('⚠️  NOTE: This is a placeholder bundle script. In a real environment, use "npm install -g esbuild" and run:');
console.log(`esbuild apps/bot/src/index.ts --bundle --platform=node --target=node18 --outfile=deploy-bot/bot.js --external:discord.js --external:@prisma/client`);

// Let's write a simple esbuild script content instead if user can run it locally
