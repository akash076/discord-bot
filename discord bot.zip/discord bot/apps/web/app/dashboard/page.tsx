import { prisma } from '@repo/db';

async function getStats() {
    // Mock data if DB not connected in this env
    try {
        const totalDeals = await prisma.deal.count();
        const activeDeals = await prisma.deal.count({
            where: { expiresAt: { gt: new Date() } }
        });
        return { totalDeals, activeDeals };
    } catch (e) {
        return { totalDeals: 124, activeDeals: 15 };
    }
}

export default async function DashboardPage() {
    const stats = await getStats();

    return (
        <div className="space-y-8">
            <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold text-white">Dashboard Overview</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 p-6 rounded-2xl">
                    <h3 className="text-slate-400 text-sm font-medium uppercase tracking-wider">Active Deals</h3>
                    <p className="text-4xl font-bold text-purple-400 mt-2">{stats.activeDeals}</p>
                </div>
                <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 p-6 rounded-2xl">
                    <h3 className="text-slate-400 text-sm font-medium uppercase tracking-wider">Total Deals Found</h3>
                    <p className="text-4xl font-bold text-blue-400 mt-2">{stats.totalDeals}</p>
                </div>
                <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 p-6 rounded-2xl">
                    <h3 className="text-slate-400 text-sm font-medium uppercase tracking-wider">Servers Active</h3>
                    <p className="text-4xl font-bold text-pink-400 mt-2">--</p>
                </div>
            </div>

            {/* Recent Deals Table Mockup */}
            <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 rounded-2xl overflow-hidden">
                <div className="p-6 border-b border-slate-800">
                    <h3 className="text-xl font-semibold">Recent Deals</h3>
                </div>
                <div className="p-6 text-center text-slate-500">
                    Connect Database to view live feed.
                </div>
            </div>
        </div>
    );
}
