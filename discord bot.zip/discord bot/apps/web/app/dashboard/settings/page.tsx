'use client';
import { useState } from 'react';

export default function SettingsPage() {
    const [enabled, setEnabled] = useState(true);

    return (
        <div className="space-y-8">
            <div>
                <h2 className="text-3xl font-bold text-white">Server Settings</h2>
                <p className="text-slate-400 mt-2">Configure how the bot behaves in your server.</p>
            </div>

            <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 rounded-2xl p-8 space-y-6">

                <div className="flex items-center justify-between">
                    <div>
                        <h3 className="text-lg font-medium text-white">Enable Deal Alerts</h3>
                        <p className="text-slate-400 text-sm">Toggle all deal notifications.</p>
                    </div>
                    <button
                        onClick={() => setEnabled(!enabled)}
                        className={`w-14 h-7 rounded-full transition-colors relative ${enabled ? 'bg-purple-600' : 'bg-slate-700'}`}
                    >
                        <div className={`absolute top-1 left-1 bg-white w-5 h-5 rounded-full transition-transform ${enabled ? 'translate-x-7' : 'translate-x-0'}`} />
                    </button>
                </div>

                <div className="pt-6 border-t border-slate-800">
                    <h3 className="text-lg font-medium text-white mb-4">Sources</h3>
                    <div className="space-y-4">
                        {['Epic Games', 'Steam', 'Reddit', 'GOG'].map((source) => (
                            <label key={source} className="flex items-center space-x-3 cursor-pointer group">
                                <input type="checkbox" defaultChecked className="w-5 h-5 rounded border-slate-700 bg-slate-800 text-purple-600 focus:ring-purple-500/50" />
                                <span className="text-slate-300 group-hover:text-white transition-colors">{source}</span>
                            </label>
                        ))}
                    </div>
                </div>

                <div className="pt-6 border-t border-slate-800">
                    <button className="bg-purple-600 hover:bg-purple-500 text-white px-6 py-2 rounded-lg font-medium transition-all shadow-lg shadow-purple-500/20">
                        Save Changes
                    </button>
                </div>
            </div>
        </div>
    );
}
