import NextAuth from "next-auth"
import Auth0Provider from "next-auth/providers/auth0"

export const authOptions = {
    providers: [
        Auth0Provider({
            clientId: process.env.AUTH0_CLIENT_ID ?? "",
            clientSecret: process.env.AUTH0_CLIENT_SECRET ?? "",
            issuer: process.env.AUTH0_ISSUER ?? "",
        }),
    ],
    callbacks: {
        async session({ session, token }: any) {
            if (session?.user) {
                // Normalize Auth0 ID to Discord ID for Bot compatibility
                // Auth0 pattern: "oauth2|discord|123456789" or "discord|123456789"
                let id = token.sub;
                if (id?.startsWith('oauth2|discord|')) {
                    id = id.replace('oauth2|discord|', '');
                } else if (id?.startsWith('discord|')) {
                    id = id.replace('discord|', '');
                } else if (id?.startsWith('auth0|')) {
                    // Fallback if they use DB connection, but ideally we want Discord ID
                }
                session.user.id = id;
                session.accessToken = token.accessToken;
            }
            return session;
        },
        async jwt({ token, account }: any) {
            if (account) {
                token.accessToken = account.access_token;
            }
            return token;
        }
    }
}

export const handler = NextAuth(authOptions);
