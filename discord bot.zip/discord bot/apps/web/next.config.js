/** @type {import('next').NextConfig} */
const nextConfig = {
    transpilePackages: ["@repo/shared"],
    images: {
        domains: ['cdn.cloudflare.steamstatic.com', 'cdn1.epicgames.com', 'external-preview.redd.it'],
    },
};

module.exports = nextConfig;
