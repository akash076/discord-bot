import Link from 'next/link';
import { Home, Settings, ShoppingBag, LogOut } from 'lucide-react';

export default function Sidebar() {
    return (
        <div className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col h-screen fixed left-0 top-0">
            <div className="p-6">
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
                    FreeStuffBot
                </h1>
            </div>

            <nav className="flex-1 px-4 space-y-2">
                <Link href="/dashboard" className="flex items-center space-x-3 px-4 py-3 text-slate-300 hover:bg-slate-800/50 rounded-xl transition-all hover:text-white group">
                    <Home className="w-5 h-5 group-hover:scale-110 transition-transform" />
                    <span>Overview</span>
                </Link>
                <Link href="/dashboard/settings" className="flex items-center space-x-3 px-4 py-3 text-slate-300 hover:bg-slate-800/50 rounded-xl transition-all hover:text-white group">
                    <Settings className="w-5 h-5 group-hover:scale-110 transition-transform" />
                    <span>Settings</span>
                </Link>
                <Link href="/wishlist" className="flex items-center space-x-3 px-4 py-3 text-slate-300 hover:bg-slate-800/50 rounded-xl transition-all hover:text-white group">
                    <ShoppingBag className="w-5 h-5 group-hover:scale-110 transition-transform" />
                    <span>My Wishlist</span>
                </Link>
            </nav>

            <div className="p-4 border-t border-slate-800">
                <button className="flex items-center space-x-3 px-4 py-3 text-slate-400 hover:text-red-400 transition-colors w-full">
                    <LogOut className="w-5 h-5" />
                    <span>Sign Out</span>
                </button>
            </div>
        </div>
    );
}
