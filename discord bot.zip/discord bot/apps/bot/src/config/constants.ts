export const STATUS_ROTATION_INTERVAL = 60000 * 10; // 10 minutes

export const ACTIVITY_STATUSES = [
    { name: 'Deals 24/7', type: 0 }, // Playing
    { name: 'for Free Games', type: 3 }, // Watching
    { name: 'Price Drops', type: 2 }, // Listening
];

export const OWNER_IDS = (process.env.DISCORD_OWNER_IDS || '').split(',');
