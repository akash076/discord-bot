import { Client, GatewayIntentBits, Collection, Interaction } from 'discord.js';
import dotenv from 'dotenv';
import cron from 'node-cron';
import { prisma } from '@repo/db';

dotenv.config();

// Extend Client implementation if needed for commands, or just use a global map
// For simplicity in this one-file view, we assume a simple structure.

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
    ]
});

import { checkDeals } from './services/deal-scanner';
import { startStatusRotation } from './services/status-service';
import { checkWishlists } from './services/wishlist-service';
import { Logger } from './services/logger-service';

// Global Error Handlers
process.on('uncaughtException', (error) => {
    Logger.error('Uncaught Exception', error);
});

process.on('unhandledRejection', (reason) => {
    Logger.error('Unhandled Rejection', reason);
});

client.once('ready', () => {
    Logger.info('Bot', `Logged in as ${client.user?.tag}!`);

    startStatusRotation(client);

    // Schedule deal check every hour
    cron.schedule('0 * * * *', async () => {
        try {
            await checkDeals(client);
        } catch (e) {
            Logger.error('Deal Scanner', e);
        }
    });

    // Schedule wishlist check every 30 mins
    cron.schedule('*/30 * * * *', async () => {
        try {
            await checkWishlists(client);
        } catch (e) {
            Logger.error('Wishlist Scanner', e);
        }
    });
});

client.on('error', (error) => {
    Logger.error('Discord Client Error', error);
});

client.on('interactionCreate', async (interaction: Interaction) => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === 'config') {
        // Handle config
        await interaction.reply({ content: 'Config command received!', ephemeral: true });
        // Logic to save config to DB
        const channel = interaction.options.getChannel('channel');
        if (channel && interaction.guildId) {
            // Upsert GuildConfig
            await prisma.guildConfig.upsert({
                where: { id: interaction.guildId },
                update: { alertChannelId: channel.id },
                create: { id: interaction.guildId, alertChannelId: channel.id }
            });
            await interaction.followUp({ content: `Alert channel set to ${channel.name}`, ephemeral: true });
        }
    }

    if (interaction.commandName === 'wishlist') {
        // Handle wishlist
        await interaction.reply('Wishlist command processed.');
    }
});

client.login(process.env.DISCORD_TOKEN);
