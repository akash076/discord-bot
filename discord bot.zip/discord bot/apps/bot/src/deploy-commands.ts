import { REST, Routes } from 'discord.js';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';

dotenv.config();

const commands: any[] = [];
// In a real scenario, we would dynamic import commands here.
// For now, we'll manually push or import them once defined.
// Placeholder for now.

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN!);

(async () => {
    try {
        console.log('Started refreshing application (/) commands.');

        // We will replace this with actual command data later
        const commandData = [
            {
                name: 'config',
                description: 'Configure the bot for this server',
                options: [
                    {
                        name: 'channel',
                        description: 'The channel to post deals in',
                        type: 7, // CHANNEL
                        required: false
                    }
                ]
            },
            {
                name: 'wishlist',
                description: 'Manage your wishlist',
                options: [
                    {
                        name: 'add',
                        description: 'Add a game to your wishlist',
                        type: 1, // SUB_COMMAND
                        options: [{ name: 'game', description: 'Name of the game', type: 3, required: true }]
                    }
                ]
            }
        ];

        await rest.put(
            Routes.applicationCommands(process.env.DISCORD_CLIENT_ID!),
            { body: commandData },
        );

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
})();
