import axios from 'axios';
import { Deal } from '@repo/shared';

const CHEAPSHARK_API = 'https://www.cheapshark.com/api/1.0/deals?storeID=1&upperPrice=0'; // Steam, Free

export async function fetchSteamFreeGames(): Promise<Deal[]> {
    try {
        const response = await axios.get(CHEAPSHARK_API);
        const data = response.data;
        // CheapShark returns an array of deals

        return data.map((d: any) => ({
            id: `STEAM-${d.dealID}`,
            title: d.title,
            url: `https://www.cheapshark.com/redirect?dealID=${d.dealID}`,
            price: 0,
            originalPrice: parseFloat(d.normalPrice),
            discount: parseFloat(d.savings),
            expiry: new Date(d.lastChange * 1000 + 86400000), // Approximate if unknown, or just current
            source: 'STEAM',
            imageUrl: d.thumb
        }));
    } catch (error) {
        console.error('Error fetching Steam games:', error);
        return [];
    }
}
