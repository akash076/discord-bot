import { Client, TextChannel } from 'discord.js';
import { prisma } from '@repo/db';

export async function checkWishlists(client: Client) {
    console.log('Checking wishlists...');
    // 1. Get all active deals (posted recently)
    // For "Ending Soon", we'd check active deals expiring in <10h

    const endingSoonDeals = await prisma.deal.findMany({
        where: {
            expiresAt: {
                gt: new Date(),
                lt: new Date(Date.now() + 10 * 60 * 60 * 1000) // 10 hours from now
            }
        }
    });

    if (endingSoonDeals.length === 0) return;

    // 2. Fetch all active wishlists
    const wishlists = await prisma.wishlist.findMany();

    for (const deal of endingSoonDeals) {
        for (const list of wishlists) {
            // Simple string matching
            if (deal.title.toLowerCase().includes(list.query.toLowerCase())) {
                // Check if already notified recently? (skipped for simplicity, assume cron frequency handles or DB field logic needed)
                try {
                    const user = await client.users.fetch(list.userId);
                    if (user) {
                        await user.send(`🚨 **Ending Soon:** ${deal.title} is free/discounted! \n${deal.url}\nEnds at: ${deal.expiresAt}`);
                        console.log(`Notified ${user.tag} about ${deal.title}`);
                    }
                } catch (e) {
                    console.error(`Failed to DM user ${list.userId}`, e);
                }
            }
        }
    }
}
