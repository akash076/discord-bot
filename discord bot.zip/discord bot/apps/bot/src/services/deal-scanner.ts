import { Client } from 'discord.js';
import { fetchEpicFreeGames } from './epic-service';
import { fetchSteamFreeGames } from './steam-service';
import { fetchRedditFreeGames } from './reddit-service';
import { notifyDeals } from './notifier-service';
import { Deal } from '@repo/shared';

export async function checkDeals(client: Client) {
    console.log('Fetching deals...');

    const [epic, steam, reddit] = await Promise.all([
        fetchEpicFreeGames(),
        fetchSteamFreeGames(),
        fetchRedditFreeGames()
    ]);

    const allDeals: Deal[] = [...epic, ...steam, ...reddit];
    console.log(`Found ${allDeals.length} potential deals.`);

    await notifyDeals(client, allDeals);
}
