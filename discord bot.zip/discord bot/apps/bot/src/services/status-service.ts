import { Client, ActivityType } from 'discord.js';
import { ACTIVITY_STATUSES, STATUS_ROTATION_INTERVAL } from '../config/constants';

let currentStatusIndex = 0;

export function startStatusRotation(client: Client) {
    console.log('Starting Status Rotation Service...');

    const rotate = () => {
        const activity = ACTIVITY_STATUSES[currentStatusIndex];
        client.user?.setActivity(activity.name, { type: activity.type as any });

        currentStatusIndex = (currentStatusIndex + 1) % ACTIVITY_STATUSES.length;
    };

    rotate(); // Initial set
    setInterval(rotate, STATUS_ROTATION_INTERVAL);
}
