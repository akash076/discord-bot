import axios from 'axios';

const WEBHOOK_URL = process.env.LOGGING_WEBHOOK_URL;

export class Logger {
    static async error(context: string, error: any) {
        console.error(`[${context}]`, error);

        if (!WEBHOOK_URL) return;

        try {
            const errorMessage = error instanceof Error ? error.message : String(error);
            const stack = error instanceof Error ? error.stack : '';

            await axios.post(WEBHOOK_URL, {
                embeds: [{
                    title: `🚨 Error: ${context}`,
                    description: `\`\`\`js\n${errorMessage}\n\`\`\``,
                    fields: stack ? [{ name: 'Stack Trace', value: `\`\`\`js\n${stack.slice(0, 1000)}\n\`\`\`` }] : [],
                    color: 0xFF0000,
                    timestamp: new Date().toISOString()
                }]
            });
        } catch (webhookError) {
            console.error('Failed to send error to webhook:', webhookError);
        }
    }

    static async info(context: string, message: string) {
        console.log(`[${context}] ${message}`);
        // Optional: Log info to webhook too if needed, but usually too noisy.
    }
}
