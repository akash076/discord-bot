import { Client, EmbedBuilder, TextChannel } from 'discord.js';
import { Deal } from '@repo/shared';
import { prisma } from '@repo/db';

export async function notifyDeals(client: Client, deals: Deal[]) {
    // 1. Filter out deals already posted globally (or per guild logic, but usually global cache)
    // In this simple version, we check if the deal exists in DB.

    const newDeals: Deal[] = [];

    for (const deal of deals) {
        const existing = await prisma.deal.findUnique({ where: { externalId: deal.id } });
        if (!existing) {
            await prisma.deal.create({
                data: {
                    externalId: deal.id,
                    title: deal.title,
                    url: deal.url,
                    price: deal.price,
                    originalPrice: deal.originalPrice,
                    discount: deal.discount,
                    source: deal.source,
                    expiresAt: deal.expiry
                }
            });
            newDeals.push(deal);
        }
    }

    if (newDeals.length === 0) return;

    // 2. Fetch all guild configs
    const configs = await prisma.guildConfig.findMany();

    for (const deal of newDeals) {
        const embed = new EmbedBuilder()
            .setTitle(deal.title)
            .setURL(deal.url)
            .setDescription(`**${deal.discount}% OFF!**\nFree! (Was $${deal.originalPrice})`)
            .setColor(0x00FF00)
            .setTimestamp()
            .setFooter({ text: `Source: ${deal.source}` });

        if (deal.imageUrl) {
            embed.setThumbnail(deal.imageUrl);
        }

        for (const config of configs) {
            if (config.alertChannelId) {
                // Check filters
                if (config.blockedSources?.includes(deal.source)) continue;

                try {
                    const channel = await client.channels.fetch(config.alertChannelId) as TextChannel;
                    if (channel) {
                        let content = '';
                        if (config.rolesToMention) {
                            content = config.rolesToMention.split(',').map(r => `<@&${r}>`).join(' ');
                        }
                        await channel.send({ content: content || undefined, embeds: [embed] });
                    }
                } catch (e) {
                    // Channel might be deleted or bot kicked
                    console.error(`Failed to send to guild ${config.id}`, e);
                }
            }
        }
    }
}
