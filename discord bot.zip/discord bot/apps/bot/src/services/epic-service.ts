import axios from 'axios';
import { Deal } from '@repo/shared';
import { prisma } from '@repo/db';

const EPIC_API_URL = 'https://store-site-backend-static.ak.epicgames.com/freeGamesPromotions';

export async function fetchEpicFreeGames(): Promise<Deal[]> {
    try {
        const response = await axios.get(EPIC_API_URL);
        const games = response.data.data.Catalog.searchStore.elements;

        const deals: Deal[] = [];

        for (const game of games) {
            // Filter for active promotions
            const promotions = game.promotions;
            if (!promotions || !promotions.promotionalOffers || promotions.promotionalOffers.length === 0) continue;

            const offer = promotions.promotionalOffers[0].promotionalOffers.find((o: any) =>
                new Date(o.startDate) <= new Date() && new Date(o.endDate) > new Date() && o.discountSetting.discountPercentage === 0
            );

            if (offer) {
                deals.push({
                    id: `EPIC-${game.id}`,
                    title: game.title,
                    url: `https://store.epicgames.com/en-US/p/${game.productSlug || game.urlSlug}`,
                    price: 0,
                    originalPrice: game.price.totalPrice.originalPrice / 100, // API returns cents usually
                    discount: 100,
                    expiry: new Date(offer.endDate),
                    source: 'EPIC',
                    imageUrl: game.keyImages.find((img: any) => img.type === 'Thumbnail')?.url || game.keyImages[0]?.url
                });
            }
        }
        return deals;
    } catch (error) {
        console.error('Error fetching Epic games:', error);
        return [];
    }
}
