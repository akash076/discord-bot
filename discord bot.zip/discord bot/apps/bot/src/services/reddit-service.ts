import axios from 'axios';
import { Deal } from '@repo/shared';

const REDDIT_API = 'https://www.reddit.com/r/GameDeals/new.json?limit=25';

export async function fetchRedditFreeGames(): Promise<Deal[]> {
    try {
        const response = await axios.get(REDDIT_API);
        const posts = response.data.data.children;

        const deals: Deal[] = [];

        for (const post of posts) {
            const data = post.data;
            const title = data.title.toLowerCase();

            // Simple heuristic for free deals
            if (title.includes('100%') || title.includes('free')) {
                deals.push({
                    id: `REDDIT-${data.id}`,
                    title: data.title,
                    url: data.url,
                    price: 0,
                    originalPrice: 0, // Hard to parse from title cleanly without regex magic
                    discount: 100,
                    expiry: new Date(Date.now() + 86400000), // 24h default
                    source: 'REDDIT',
                    imageUrl: data.thumbnail !== 'default' ? data.thumbnail : undefined
                });
            }
        }
        return deals;
    } catch (error) {
        console.error('Error fetching Reddit deals:', error);
        return [];
    }
}
